
# AIML 428 Assignment-2 NLP

This is the AIML428 Assignment 2. Where DistilGPT-2 has been implemeted on two tasks along with Fine-Tuning.

Make sure to run this notebook in Google Colab with a GPU in the runtime connection.


Directly uploading the notebook on Google Colab and running it would be sufficient.

The Zip-File consists of this readme file, NLP_Assignment-2.ipynb file and a report for the assignment called AIML428_ NLP Assignment-2 Report.pdf










